require("dotenv").config();
const { connectMongoDB, disconnectMongoDB } = require("../../services/mongodb");
const superTest = require("supertest");
const app = require("../../app");

beforeAll(async () => {
	await connectMongoDB();
});

afterAll(async () => {
	await disconnectMongoDB();
});

describe("POST /users", () => {
	test("post a valid user", async () => {
		const validUser = {
			username: "test0user",
			password: "test0p@Ssword",
			email: "test@user.com",
			role: "user",
		};
		const response = await superTest(app).post("/users").send(validUser);
		expect(response.status).toBe(201);
	});

	test("post invalid user", async () => {
		const invalidUser = {
			username: "test user",
			password: "test0p@Ssword",
			email: "test@user.com",
			role: "user",
		};
		const response = await superTest(app).post("/users").send(invalidUser);
		expect(response.status).toBe(400);
	});
});
